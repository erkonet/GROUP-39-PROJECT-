package com.ug.wifisupport

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*

private const val BASE_URL = "http://10.0.2.2:5000/"

data class LoginRequest(val student_id: String, val password: String)
data class LoginResponse(val access_token: String, val student_id: String, val name: String, val role: String)
data class ReportRequest(val location: String, val issue_type: String, val description: String)
data class Ticket(val id: String, val location: String, val issue: String, val description: String = "", val status: String)
data class Router(val router_id: String, val location: String, val signal: Int, val status: String)

interface ApiService {
    @POST("api/login") suspend fun login(@Body body: LoginRequest): LoginResponse
    @POST("api/report") suspend fun report(@Header("Authorization") token: String, @Body body: ReportRequest): Map<String,String>
    @GET("api/tickets") suspend fun tickets(@Header("Authorization") token: String): List<Ticket>
    @GET("api/signal-map") suspend fun signalMap(): List<Router>
    @GET("api/admin/tickets") suspend fun adminTickets(@Header("Authorization") token: String): List<Ticket>
    @PATCH("api/admin/tickets/{id}") suspend fun updateTicket(@Header("Authorization") token: String, @Path("id") id: String, @Body body: Map<String,String>): Map<String,String>
}

object Api {
    val service: ApiService = Retrofit.Builder()
        .baseUrl(BASE_URL).addConverterFactory(GsonConverterFactory.create()).build()
        .create(ApiService::class.java)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
fun App() {
    val nav = androidx.navigation.compose.rememberNavController()
    var token by remember { mutableStateOf("") }
    var role by remember { mutableStateOf("student") }

    androidx.navigation.compose.NavHost(nav, "login") {
        androidx.navigation.compose.composable("login") {
            Login { t, r -> token = t; role = r; nav.navigate(if (r=="admin") "admin" else "home") }
        }
        androidx.navigation.compose.composable("home") {
            Dashboard({ nav.navigate("report") }, { nav.navigate("tickets") }, { nav.navigate("signal") }) {
                token=""; nav.navigate("login")
            }
        }
        androidx.navigation.compose.composable("report") { Report(token) { nav.popBackStack() } }
        androidx.navigation.compose.composable("tickets") { Tickets(token) }
        androidx.navigation.compose.composable("signal") { Signal() }
        androidx.navigation.compose.composable("admin") { Admin(token) }
    }
}

@Composable
fun Login(done: (String,String)->Unit) {
    var id by remember { mutableStateOf("") }; var pass by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }; val scope=rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement=Arrangement.Center) {
        Text("UG Wi-Fi Support", style=MaterialTheme.typography.headlineMedium)
        Text("Secure campus Wi-Fi assistance")
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(id,{id=it},label={Text("Student/Admin ID")},Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(pass,{pass=it},label={Text("Password")},Modifier.fillMaxWidth())
        Spacer(Modifier.height(16.dp))
        Button(Modifier.fillMaxWidth(), onClick={
            scope.launch {
                try { val r=withContext(Dispatchers.IO){Api.service.login(LoginRequest(id,pass))}
                    done("Bearer ${r.access_token}",r.role)
                } catch(e:Exception){ msg="Login failed. Check credentials and server." }
            }
        }) { Text("Sign in") }
        if(msg.isNotEmpty()) Text(msg,Modifier.padding(top=12.dp))
    }
}

@Composable
fun Dashboard(report:()->Unit,tickets:()->Unit,signal:()->Unit,logout:()->Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("Student Dashboard",style=MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(20.dp))
        Button(report,Modifier.fillMaxWidth()){Text("Report Wi-Fi Problem")}
        Spacer(Modifier.height(10.dp)); Button(tickets,Modifier.fillMaxWidth()){Text("My Tickets")}
        Spacer(Modifier.height(10.dp)); Button(signal,Modifier.fillMaxWidth()){Text("Wi-Fi Signal")}
        Spacer(Modifier.height(20.dp)); OutlinedButton(logout,Modifier.fillMaxWidth()){Text("Logout")}
    }
}

@Composable
fun Report(token:String,back:()->Unit) {
    var loc by remember{mutableStateOf("")};var issue by remember{mutableStateOf("")};var desc by remember{mutableStateOf("")};var msg by remember{mutableStateOf("")};val scope=rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(24.dp)){
        Text("Report a Problem",style=MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(16.dp));OutlinedTextField(loc,{loc=it},label={Text("Location")},Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp));OutlinedTextField(issue,{issue=it},label={Text("Issue type")},Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp));OutlinedTextField(desc,{desc=it},label={Text("Description")},Modifier.fillMaxWidth(),minLines=4)
        Spacer(Modifier.height(16.dp));Button(Modifier.fillMaxWidth(),onClick={scope.launch{try{val r=withContext(Dispatchers.IO){Api.service.report(token,ReportRequest(loc,issue,desc))};msg="Ticket created: ${r["ticket_id"]}"}catch(e:Exception){msg="Submission failed."}}}){Text("Submit")}
        if(msg.isNotEmpty())Text(msg,Modifier.padding(top=12.dp));Spacer(Modifier.height(12.dp));OutlinedButton(back,Modifier.fillMaxWidth()){Text("Back")}
    }
}

@Composable
fun Tickets(token:String) {
    var list by remember{mutableStateOf<List<Ticket>>(emptyList())};var msg by remember{mutableStateOf("")}
    LaunchedEffect(Unit){try{list=withContext(Dispatchers.IO){Api.service.tickets(token)}}catch(e:Exception){msg="Could not load tickets."}}
    Column(Modifier.fillMaxSize().padding(24.dp)){Text("My Tickets",style=MaterialTheme.typography.headlineSmall);Text(msg)
        LazyColumn{items(list){t->Card(Modifier.fillMaxWidth().padding(vertical=5.dp)){Column(Modifier.padding(14.dp)){Text("ID: ${t.id}");Text("${t.issue} • ${t.location}");Text("Status: ${t.status}");Text(t.description)}}}}
    }
}

@Composable
fun Signal() {
    var list by remember{mutableStateOf<List<Router>>(emptyList())};var msg by remember{mutableStateOf("")}
    LaunchedEffect(Unit){try{list=withContext(Dispatchers.IO){Api.service.signalMap()}}catch(e:Exception){msg="Could not load signal data."}}
    Column(Modifier.fillMaxSize().padding(24.dp)){Text("Wi-Fi Signal",style=MaterialTheme.typography.headlineSmall);Text(msg)
        LazyColumn{items(list){r->Card(Modifier.fillMaxWidth().padding(vertical=5.dp)){Column(Modifier.padding(14.dp)){Text(r.location);Text("${r.signal}% signal • ${r.status}")}}}}
    }
}

@Composable
fun Admin(token:String) {
    var list by remember{mutableStateOf<List<Ticket>>(emptyList())};var msg by remember{mutableStateOf("")};val scope=rememberCoroutineScope()
    LaunchedEffect(Unit){try{list=withContext(Dispatchers.IO){Api.service.adminTickets(token)}}catch(e:Exception){msg="Admin access failed."}}
    Column(Modifier.fillMaxSize().padding(20.dp)){Text("Admin Dashboard",style=MaterialTheme.typography.headlineMedium);Text(msg)
        LazyColumn{items(list){t->var status by remember(t.id,t.status){mutableStateOf(t.status)}
            Card(Modifier.fillMaxWidth().padding(vertical=5.dp)){Column(Modifier.padding(14.dp)){
                Text("Ticket ${t.id}");Text("Student/location: ${t.location}");Text(t.issue);Text("Current: $status")
                Row{listOf("Open","In Progress","Resolved").forEach{s->TextButton(onClick={status=s;scope.launch{try{withContext(Dispatchers.IO){Api.service.updateTicket(token,t.id,mapOf("status" to s))}}catch(_:Exception){}}}){Text(s)}}}
            }}
        }}
    }
}
